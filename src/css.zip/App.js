import './css/style.css';
import './App.css';

import { Header} from "./component/Header.jsx";
import { Navbar } from "./component/Navbar.jsx";
import { ContentDisplay} from "./component/ContentDisplay.jsx"
import { Account } from "./component/Account.jsx";
import { Vendor } from "./component/Vendor.jsx";
import { Customer } from "./component/Customer.jsx";
import { Contact } from "./component/Contact.jsx";
import {
  BrowerRouter as Router,
  Routes,
  Route,
  Link
}
from 'React-router-dom';
 function Menu(){
  return(
      <ul>
      <li><link to ="/">Account </link>
       </li>
      <li><Link to ="vendor">Vendor Detail</Link>  </li>
      <li><Link to ="customer">Customer Detail </Link>  </li>
      <li><Link to ="contact">Contact US </Link> </li>
      
      </ul>
  )
  
  
}



function App() {
  return (
    <div className="App">
      <Header/>
      <Navbar/>
      <Router>
        <div>

        </div>
        <Menu/>
        <Routes>
                <Route exact path ="/" element={<Account/>}></Route>
                <Route exact path ="" element={<Vendor/>}></Route>
                <Route exact path ="" element={<Customer/>}></Route>
                <Route exact path ="" element={<Contact/>}></Route>
        </Routes>
        <div>
          
        </div>
      </Router>
     
      <ContentDisplay/>
    

     
    </div>
  );
}

export default App;
