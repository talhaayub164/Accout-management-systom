import React, { useState } from 'react';
import '../css/style.css';
import { ContentDisplay} from './ContentDisplay'

export function Navbar() {
    const [content, setContent] = useState('');

    const handleNavigationClick = (newContent) => {
        setContent(newContent);
    };

    return (
        <div className="navbar">
            <ul>
                <li onClick={() => handleNavigationClick("<h1>Home</h1>Home This is some dynamic text")}>
                    Home
                </li>
                <li onClick={() => handleNavigationClick("<h1>Employe Foam</h1> <label>Employe Name</label><input type='text' id='name'placholder='Enter Your Name' value=''/><br><label>CNIC</label><input type='number' id='cnic'value=''/>")}>
                    Employee Form
                </li>
                <li onClick={() => handleNavigationClick("Customer Form")}>
                    Customer Form
                </li>
                <li onClick={() => handleNavigationClick("Vendor Form")}>
                    Vendor Form
                </li>
            </ul>
    <ContentDisplay content={content} />
            
        </div>
    );
}
