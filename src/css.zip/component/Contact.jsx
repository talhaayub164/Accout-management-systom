import './css/style.css';
export default function Contact(){
    return(
        <div className="acc">
            <h1>Accounts</h1>
        </div>
    );
}