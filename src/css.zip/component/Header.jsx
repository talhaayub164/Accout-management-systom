import '../css/style.css'
export function Header(){
    return(
        <div className="container">
        <header>ACcount Managemnet Systom </header>
        </div>
        
    )
}