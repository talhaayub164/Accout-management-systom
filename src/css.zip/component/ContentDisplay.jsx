
import '../css/style.css';

export function ContentDisplay({ content ,content1}) {
    return (
        <div className="container">
            <br />
        <div className="box" id="box" dangerouslySetInnerHTML={{ __html: content }} />
        <div className="box" id="box" dangerouslySetInnerHTML={{ __html: content1 }} />
        </div>
    );
}
 