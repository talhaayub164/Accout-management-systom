import '../css/style.css';
export default function Customer(){
    return(
        <div className="acc">
            <h1>Accounts</h1>
        </div>
    );
}