import '../css/style.css';
import React from 'react';

export function Account() {
    return (
        <h1>Accounts</h1>
    );
}
