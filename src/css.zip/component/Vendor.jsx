import './css/style.css';
export default function Vendor(){
    return(
    
            <h1>Accounts</h1>
    );
}